import { createContext, useContext } from "react";

export const ThemeContext = createContext({ isDark: false });

export const useTheme = () => useContext(ThemeContext);
